import asyncio
import logging
import shutil
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from errors import ApiError, envelope


@dataclass
class Job:
    image_path: Path
    filename: str
    dpi: float
    params: dict
    rois: list
    preview: bool = False
    id: str = field(default_factory=lambda: str(uuid4()))
    queued_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"))
    status: str = "pending"
    terminal: tuple | None = None
    csv: str = ""


class Jobs:
    def __init__(self, runner, max_depth=10, ttl=300):
        self.runner = runner
        self.max_depth = max_depth
        self.ttl = ttl
        self.waiting = deque()
        self.running = None
        self.jobs = {}
        self.listeners = defaultdict(set)
        self.expiry = {}
        self.task = None

    def check_capacity(self):
        if len(self.waiting) >= self.max_depth:
            raise ApiError("SERVICE_AT_CAPACITY", {"queueDepth": len(self.waiting), "maxDepth": self.max_depth})

    def enqueue(self, job):
        self.check_capacity()
        position = len(self.waiting) + bool(self.running)
        self.jobs[job.id] = job
        self.waiting.append(job)
        self.publish(job, "queued", {"queuePosition": position})
        if self.task is None or self.task.done():
            self.task = asyncio.create_task(self.pump())
        return int(position)

    def publish(self, job, event, data):
        if event in ("completed", "failed"):
            job.terminal = event, data
        for listener in tuple(self.listeners.get(job.id, ())):
            listener.put_nowait((event, data))

    def subscribe(self, job):
        listener = asyncio.Queue()
        self.listeners[job.id].add(listener)
        if job.terminal is not None:
            listener.put_nowait(job.terminal)
        return listener

    def unsubscribe(self, job_id, listener):
        self.listeners[job_id].discard(listener)
        if not self.listeners[job_id]:
            del self.listeners[job_id]

    def expire(self, job_id):
        self.jobs.pop(job_id, None)
        self.expiry.pop(job_id, None)

    async def pump(self):
        while self.waiting:
            job = self.running = self.waiting.popleft()
            job.status = "processing"
            self.publish(job, "started", {})
            try:
                result, job.csv = await self.runner(job, lambda event, data: self.publish(job, event, data))
                job.status = "completed"
                self.publish(job, "completed", result)
            except ApiError as error:
                job.status = "failed"
                self.publish(job, "failed", error.envelope)
            except Exception:
                logging.exception("analysis_failed", extra={"job_id": job.id})
                job.status = "failed"
                self.publish(job, "failed", envelope("INTERNAL_ERROR"))
            finally:
                await asyncio.to_thread(shutil.rmtree, job.image_path.parent, True)
                self.expiry[job.id] = asyncio.get_running_loop().call_later(self.ttl, self.expire, job.id)
                self.running = None

    async def close(self):
        if self.task is not None:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
        for job in self.waiting:
            shutil.rmtree(job.image_path.parent, ignore_errors=True)
        for timer in self.expiry.values():
            timer.cancel()
        self.waiting.clear()
        self.expiry.clear()
        self.jobs.clear()
        self.listeners.clear()


class UploadAllowance:
    def __init__(self, limit):
        self.limit = limit
        self.addresses = {}

    def check(self, address):
        now = time.monotonic()
        self.addresses = {ip: times for ip, times in self.addresses.items() if times and times[-1] > now - 3600}
        times = self.addresses.setdefault(address, deque())
        while times and times[0] <= now - 3600:
            times.popleft()
        if len(times) >= self.limit:
            raise ApiError("RATE_LIMITED")
        times.append(now)
