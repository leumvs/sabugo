import asyncio
import base64
import io
import logging
import multiprocessing
import time

from errors import ApiError, ERROR_STATUS
from imaging import export, jsonout, render
from imaging.analysis import analyse, regions
from imaging.pipeline import Params, PipelineError, load_image, segment
from imaging.progress import Progress


def png_data_uri(image):
    import cv2

    ok, encoded = cv2.imencode(".png", image)
    if not ok:
        raise PipelineError("INTERNAL_ERROR")
    return "data:image/png;base64," + base64.b64encode(encoded).decode("ascii")


def analyse_upload(job, max_megapixels, emit=None):
    options = job.params
    params = Params(**{name: options[name] for name in Params.__dataclass_fields__ if name in options})
    params.rois = [(r["name"], r["x"], r["y"], r["width"], r["height"]) for r in job.rois]
    image = load_image(str(job.image_path), int(max_megapixels * 1_000_000))
    progress = Progress(emit, max(len(params.rois), 1))
    progress.stage("load")
    output = io.StringIO(newline="")
    table = None if job.preview else export.writer(output, params.diameter_ranges_mm, params.mode)
    results = []
    for index, (name, region) in enumerate(regions(image, params)):
        if job.preview:
            seg = segment(region, job.dpi, params)
            progress.stage("segment", name)
            values, skeleton = None, None
        else:
            values, seg, skeleton = analyse(region, job.dpi, params, progress, name)
        pictures = {"segmented": png_data_uri(render.segmented(seg.mask)), "skeleton": None}
        if skeleton is not None:
            pictures["skeleton"] = png_data_uri(render.skeleton_picture(
                seg.mask, seg.dt, skeleton, seg.mm_per_px, params.diameter_ranges_mm,
                pen=options["medial_axis_width"], holes=options["show_holes"],
                hull=options["show_convex_hull"], contour=options["show_contours"],
                contour_width=options["contour_width"], show_distance_map=options["show_dist_map"],
                medial_axis=options["show_medial_axis"], colour_by_class=options["show_medial_axis_diameter"],
            ))
        progress.stage("render", name)
        roi_index = -1 if not params.rois else index
        if values is None:
            entry = jsonout.preview(job.filename, name, roi_index, seg.threshold_value_used, pictures)
        else:
            table.writerow(export.row(job.filename, values, params.diameter_ranges_mm, name, params.mode))
            entry = jsonout.result(job.filename, name, roi_index, values, seg.threshold_value_used, pictures, params.mode)
        results.append(entry)
        progress.unit_done()
    return jsonout.document(results), output.getvalue()


def _process(connection, job, max_megapixels):
    try:
        result = analyse_upload(job, max_megapixels, lambda data: connection.send(("progress", data)))
        connection.send(("completed", result))
    except PipelineError as error:
        code = str(error)
        connection.send(("failed", code if code in ERROR_STATUS else "INTERNAL_ERROR"))
    except Exception:
        logging.exception("analysis_failed")
        connection.send(("failed", "INTERNAL_ERROR"))
    finally:
        connection.close()


async def run_analysis(job, emit, settings):
    context = multiprocessing.get_context("spawn")
    incoming, outgoing = context.Pipe(duplex=False)
    process = context.Process(target=_process, args=(outgoing, job, settings.MAX_MEGAPIXELS))
    deadline = time.monotonic() + settings.JOB_TIMEOUT_SECONDS
    try:
        process.start()
        outgoing.close()
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise ApiError("PROCESSING_TIMEOUT")
            if await asyncio.to_thread(incoming.poll, min(remaining, 0.1)):
                try:
                    event, data = await asyncio.wait_for(
                        asyncio.to_thread(incoming.recv), max(deadline - time.monotonic(), 0.001)
                    )
                except EOFError:
                    raise ApiError("INTERNAL_ERROR") from None
                except TimeoutError:
                    raise ApiError("PROCESSING_TIMEOUT") from None
                if event == "completed":
                    return data
                if event == "failed":
                    raise ApiError(data)
                emit(event, data)
            elif not process.is_alive():
                raise ApiError("INTERNAL_ERROR")
    finally:
        if process.pid is not None:
            if process.is_alive():
                process.kill()
            await asyncio.to_thread(process.join)
        incoming.close()
        outgoing.close()
        process.close()
