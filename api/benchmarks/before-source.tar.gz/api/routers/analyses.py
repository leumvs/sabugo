import asyncio
import re
import shutil
import struct
import tempfile
from pathlib import Path
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response
from fastapi.sse import EventSourceResponse, ServerSentEvent
from pydantic import Field, TypeAdapter, ValidationError
from starlette.datastructures import UploadFile

from errors import ApiError, envelope
from schemas import Accepted, AnalysisParams, ErrorEnvelope, Roi
from services.jobs import Job

router = APIRouter(tags=["analyses"])
DPI = TypeAdapter(Annotated[float, Field(ge=50, le=4800, allow_inf_nan=False)])
ROIS = TypeAdapter(Annotated[list[Roi], Field(max_length=10)])
EXTENSIONS = {"bmp": "bmp", "jpeg": "jpg", "png": "png", "tiff": "tif"}
ERROR_RESPONSES = {code: {"model": ErrorEnvelope} for code in (400, 413, 415, 429, 500, 503)}
UPLOAD_SCHEMA = {"requestBody": {"required": True, "content": {"multipart/form-data": {"schema": {
    "type": "object", "required": ["image", "dpi"], "properties": {
        "dpi": {"type": "string", "example": "600"},
        "params": {"type": "string", "description": "JSON analysis parameters"},
        "rois": {"type": "string", "description": "JSON array of up to ten rectangles"},
        "image": {"type": "string", "format": "binary"},
    },
}}}}}


def sniff_format(data):
    if data.startswith(b"BM"):
        return "bmp"
    if data.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if data.startswith((b"II*\0", b"MM\0*")):
        return "tiff"
    return None


def is_multi_page_tiff(handle, size):
    handle.seek(0)
    header = handle.read(8)
    if len(header) < 8 or sniff_format(header) != "tiff":
        return False
    order = "<" if header.startswith(b"II") else ">"
    first = struct.unpack(order + "I", header[4:])[0]
    if first < 8 or first + 2 > size:
        return False
    handle.seek(first)
    entries = struct.unpack(order + "H", handle.read(2))[0]
    offset = first + 2 + entries * 12
    if offset + 4 > size:
        return False
    handle.seek(offset)
    following = struct.unpack(order + "I", handle.read(4))[0]
    return 0 < following < size


def safe_stem(filename):
    base = re.split(r"[/\\]", filename or "")[-1]
    stem = re.sub(r"\.[^.]*$", "", base)
    return re.sub(r"[^A-Za-z0-9._-]", "_", stem)[:80] or "image"


def validated(parser, value, field):
    try:
        return parser(value)
    except ValidationError as error:
        issue = error.errors()[0]
        reason = "not_json" if issue["type"] == "json_invalid" else issue["type"]
        if reason == "value_error" and "error" in issue.get("ctx", {}):
            reason = str(issue["ctx"]["error"])
        raise ApiError("INVALID_PARAMS", {"field": field, "reason": reason}) from None


@router.post("/analyses", status_code=202, response_model=Accepted, responses=ERROR_RESPONSES, openapi_extra=UPLOAD_SCHEMA)
async def submit(request: Request, preview: Literal["0", "1"] | None = None):
    jobs = request.app.state.jobs
    settings = request.app.state.settings
    forwarded = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    address = forwarded or (request.client.host if request.client else "unknown")
    request.app.state.allowance.check(address)
    jobs.check_capacity()
    directory = None
    try:
        async with request.form(max_files=1, max_fields=3, max_part_size=256 * 1024) as form:
            if "dpi" not in form:
                raise ApiError("INVALID_PARAMS", {"field": "dpi"})
            dpi = validated(DPI.validate_python, form["dpi"], "dpi")
            params = validated(AnalysisParams.model_validate_json, form.get("params", "{}"), "params")
            rois = validated(ROIS.validate_json, form.get("rois", "[]"), "rois")
            image = form.get("image")
            if not isinstance(image, UploadFile):
                raise ApiError("INVALID_PARAMS", {"field": "image"})
            if image.size > settings.MAX_UPLOAD_BYTES:
                raise ApiError("IMAGE_TOO_LARGE")
            format = sniff_format(await image.read(16))
            if format is None:
                raise ApiError("UNSUPPORTED_FORMAT", {"reason": "magic_bytes"})
            if format == "tiff" and await asyncio.to_thread(is_multi_page_tiff, image.file, image.size):
                raise ApiError("UNSUPPORTED_FORMAT", {"reason": "multi_page_tiff"})
            await image.seek(0)
            directory = Path(tempfile.mkdtemp(prefix="sabugo-job-"))
            path = directory / ("image." + EXTENSIONS[format])
            with path.open("wb") as handle:
                await asyncio.to_thread(shutil.copyfileobj, image.file, handle)
            job = Job(path, safe_stem(image.filename) + "." + EXTENSIONS[format], dpi,
                      params.model_dump(), [r.model_dump() for r in rois], preview == "1")
        position = jobs.enqueue(job)
        directory = None
        return Accepted(id=job.id, queuePosition=position, queuedAt=job.queued_at)
    finally:
        if directory is not None:
            await asyncio.to_thread(shutil.rmtree, directory, True)


def sse_headers(response: Response):
    response.headers["Content-Encoding"] = "Identity"


@router.get("/analyses/{id}/events", response_class=EventSourceResponse, dependencies=[Depends(sse_headers)])
async def events(id: str, request: Request):
    jobs = request.app.state.jobs
    job = jobs.jobs.get(id)
    if job is None:
        yield ServerSentEvent(event="failed", data=envelope("NOT_FOUND"))
        return
    listener = jobs.subscribe(job)
    try:
        while True:
            event, data = await listener.get()
            yield ServerSentEvent(event=event, data=data)
            if event in ("completed", "failed"):
                return
    finally:
        jobs.unsubscribe(id, listener)


@router.get("/analyses/{id}/export", responses={200: {"content": {"text/csv": {"schema": {"type": "string"}}}}, 404: {"model": ErrorEnvelope}})
def download(id: str, request: Request, format: Literal["csv"] = "csv"):
    job = request.app.state.jobs.jobs.get(id)
    if job is None or job.status != "completed" or not job.csv:
        raise ApiError("NOT_FOUND")
    return Response(job.csv, media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="sabugo-{id}.csv"'})
